# Patch set: naming & structure cleanup

Четири групи промени, подредени по нарастваща рисковост. Може да се apply-нат като един PR (както решихме), но логически са обособени за review.

## Patch 1 — Cosmetic (risk: none)

- `.gitignore` — типични editor/OS entries
- `apps/website/deployment.yaml` — махнат дубликат `BACKEND_URL`, фикс `reloader.stakater.com/auto: "auto"` → `"true"`
- `apps/website/ghrc-auth.yaml` → `ghcr-auth.yaml` (typo)
- `vault/README.md` — довършена секция `### kubernetes`
- Изтрити мъртви файлове:
  - `infrastructure/observability/victoriametrics/rules/kustomization.yaml`
  - `infrastructure/observability/victoriametrics/scrapes/kustomization.yaml`

## Patch 2 — Reloader unification (risk: low)

Всички targeted reloader annotations (`secret.reloader.stakater.com/reload:`, `configmap.reloader.stakater.com/reload:`) → `reloader.stakater.com/auto: "true"`.

Засегнати:
- `apps/minio/statefulset.yaml`
- `apps/postgres/statefulset.yaml`
- `infrastructure/observability/exporters/postgres-exporter/deployment.yaml`
- `infrastructure/observability/exporters/kube-state-metrics/deployment.yaml`

Поведението е идентично (всички засегнати pod-ове ползват `envFrom`/`secretKeyRef`/`volumeMounts`, които Reloader auto следи).

## Patch 3 — Observability restructure (risk: medium)

- `infrastructure/observability/victoriametrics/alertmanager/` → `infrastructure/observability/alertmanager/`
- `infrastructure/observability/victoriametrics/kustomization.yaml` — без alertmanager reference, с explicit списък на scrapes
- Новият Kustomization `obs-alertmanager` (вж. Patch 4)

## Patch 4 — Kustomization CR rename (risk: high — изисква ръчни стъпки при deploy)

Всички Kustomization CRs в `kustomizations/` преименувани в схемата `<категория>-<име>`:

| Стар | Нов |
|---|---|
| `traefik` | `infra-traefik` |
| `cert-manager` | `infra-cert-manager` |
| `cert-manager-issuer` | `infra-cert-manager-issuer` |
| `external-secrets-operator` | `infra-external-secrets-operator` |
| `external-secrets` | `infra-secret-store` |
| `reloader` | `infra-secret-reloader` |
| `image-automation` | `infra-image-automation` |
| `receiver` | `infra-receiver` |
| `minio-init` | `apps-minio-init` |
| `observability-vm-operator` | `obs-victoriametrics-operator` |
| `observability-exporters` | `obs-exporters` |
| `observability-vm` | `obs-victoriametrics` |
| `observability-victorialogs` | `obs-victorialogs` |
| `observability-grafana` | `obs-grafana` |
| — (нов) | `obs-alertmanager` |

Файловете също са преименувани (`ingress-traefik.yaml` → `infra-traefik.yaml` и т.н.).

`apps-postgres`, `apps-minio`, `apps-directus`, `apps-website` запазват имената, но `dependsOn` полетата им са обновени.

---

## Deploy процедура

**ВАЖНО**: Rename на Kustomization CR не е in-place. Ако просто merge-неш PR-а без допълнителни стъпки, Flux ще види "този Kustomization вече не съществува в git" и ще prune-не **цялата** му inventory (всички HelmRelease-и, Secrets, Deployments под него). После ще създаде новия Kustomization и ще reconcile-ва от нулата. Това означава downtime на всичко.

Правилният ред:

```bash
# 1. Suspend root — да не reconcile-ва докато работим
flux suspend kustomization flux-system

# 2. Merge PR-а в main (GitHub вече има новия код, но клъстерът още не го е pull-нал
#    защото root-ът е suspended)

# 3. Ръчно изтрий старите Kustomization CRs с --cascade=orphan,
#    за да НЕ се trigger-не prune под тях.
kubectl delete kustomization -n flux-system --cascade=orphan \
  traefik \
  cert-manager \
  cert-manager-issuer \
  external-secrets-operator \
  external-secrets \
  reloader \
  image-automation \
  receiver \
  minio-init \
  observability-vm-operator \
  observability-exporters \
  observability-vm \
  observability-victorialogs \
  observability-grafana

# 4. Resume root — сега Flux ще види новите Kustomization-и и ще ги adopt-не
#    съществуващите ресурси по label match (kustomize.toolkit.fluxcd.io/name).
flux resume kustomization flux-system

# 5. Watch
flux get kustomizations --watch
```

Очаквано поведение: всички нови Kustomization-и трябва да минат през `Progressing` и да стигнат до `Ready=True` за минути, БЕЗ pod restarts и БЕЗ промяна на съществуващите Secret/Deployment/StatefulSet обекти.

### Какво да следиш за аномалии

```bash
# Нищо не трябва да се трие
kubectl get events --all-namespaces --field-selector reason=Killing -w

# Kustomization-ите не трябва да reconcile-ват ресурси "from scratch"
kubectl logs -n flux-system -l app=kustomize-controller -f | grep -i "pruned\|created"
```

Ако видиш prune event-и за workload ресурси — спри, изследвай, евентуално rollback.

### Rollback plan

Ако нещо се счупи преди стъпка 5:

```bash
# Върни PR-а
git revert <commit>
git push
flux reconcile kustomization flux-system --with-source
```

Ако се счупи **след** стъпка 5 (нови Kustomization-и са активни, но нещо не е наред): revert-ни PR-а, Flux ще види старите имена, ще ги recreate-не и ще adopt-не всичко обратно. Но ще мине още един cycle от delete/create на CR-ите, което пак не е идеално — по-добре не стигай до тук.

---

## Важни бележки за apps/website/ghcr-auth.yaml и flux-system/ghcr-auth

Имаш **два** ExternalSecret-а с едно и също име `ghcr-auth`, в два различни namespace-а:

- `flux-system/ghcr-auth` — за Flux image automation (нужен)
- `website/ghcr-auth` — за pod imagePullSecrets на website deployment-а (нужен)

И двата четат от `secret/flux.ghcr_auth` във Vault. Това е ок и остава както е — просто е worth да го знаеш като поддържан duplication.
